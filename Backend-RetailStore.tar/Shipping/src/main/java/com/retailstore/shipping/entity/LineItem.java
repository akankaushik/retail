package com.retailstore.shipping.entity;

import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LineItem {
	
    private long productId;

    private String productName;

    private int quantity;

    private double price;

}
