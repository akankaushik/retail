package com.retailstore.product.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.retailstore.product.entity.Product;
import com.retailstore.product.repository.ProductRepository;

@Service
public class ProductService {
	
	@Autowired
	private ProductRepository productRepository;
	
	public List<Product> getAllProducts(){
		return productRepository.findAll();
	}
	
	public Product addProduct(Product product) {
		return productRepository.save(product);
	}
	
	public Product getProduct(Long id) {
		Optional<Product> byId = productRepository.findById(id);
		return byId.orElse(null);
	}
	
	public String deleteproduct(Long id) {
		productRepository.deleteById(id);
		return "Deleted Sucessfully";
	}
	
	public Product updateProduct(Long id,Product product) {
		Optional<Product> byId = productRepository.findById(id);
		if(byId.isPresent()) {
			Product product1 = byId.get();
			product1.setProductName(product.getProductName());
			product1.setProductDescription(product.getProductDescription());
			product1.setProductPrice(product.getProductPrice());
			return productRepository.save(product1);
		}
		return null;
	}

}
