package com.retailstore.inventory.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.retailstore.inventory.entity.Inventory;
import com.retailstore.inventory.service.InventoryService;

@RestController
@RequestMapping("/api/inventory") 
public class InventoryController {


@Autowired
private InventoryService inventoryService;

@GetMapping("/all")
public ResponseEntity<List<Inventory>> getAllInventories() {

List<Inventory> allInventories = inventoryService.getAllInventories();

return ResponseEntity.status(HttpStatus.OK).body(allInventories);

}

@PostMapping
public ResponseEntity <Inventory> addInventory (@RequestBody Inventory inventory) {
	return ResponseEntity.status(HttpStatus.CREATED).body (inventoryService.addInventory(inventory));
}

@GetMapping("/{id}")
public ResponseEntity<Inventory> searchInventory(@PathVariable long id) {
	return ResponseEntity.status(HttpStatus.OK).body(inventoryService.searchInventory(id));
}
@PutMapping("/{id}")
public ResponseEntity<Inventory> updateInventory(@PathVariable long id, @RequestBody Inventory inventory){
	return ResponseEntity.status(HttpStatus.OK).body(inventoryService.updateInventory(id, inventory));
}

@DeleteMapping("/{id}")
public ResponseEntity<String> deleteInventory(@PathVariable long id) {
return ResponseEntity.status(HttpStatus.OK).body(inventoryService.deleteInventory(id));

}

}
