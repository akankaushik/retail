package com.retailstore.shipping.entity;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Customer {
	
	private long id;
	
	private String customerName;
	private String customerEmail;
	private String password; // Field for storing hashed password
	
	
	private CustomerAddress customerBillingAddress;
	
	
	private CustomerAddress customerShippingAddress;
	

}
