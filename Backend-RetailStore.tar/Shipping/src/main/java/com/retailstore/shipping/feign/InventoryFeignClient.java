package com.retailstore.shipping.feign;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.retailstore.shipping.entity.Inventory;

//@FeignClient(value = "inventory-service", url = "http://localhost:8093/api/inventory")
@FeignClient(value = "Inventory/api/inventory")
public interface InventoryFeignClient {

    @GetMapping("/all")
    public List<Inventory> getAllInventories(); // Remove ResponseEntity wrapper for Feign clients

    @PostMapping("/")
    public Inventory addInventory(@RequestBody Inventory inventory);

    @GetMapping("/{id}")
    public Inventory searchInventory(@PathVariable long id);

    @PutMapping("/{id}")
    public Inventory updateInventory(@PathVariable long id, @RequestBody Inventory inventory);

    @DeleteMapping("/{id}")
    public String deleteInventory(@PathVariable long id);
}

