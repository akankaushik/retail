package com.retailstore.shipping.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.retailstore.shipping.entity.CustomerOrder;

public interface CustomerOrderRepository extends JpaRepository<CustomerOrder,Long> {
	
	public List<CustomerOrder> findAllByCustomerId(long customerId);

}
