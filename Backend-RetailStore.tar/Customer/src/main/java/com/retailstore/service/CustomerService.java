package com.retailstore.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.retailstore.entity.Customer;
import com.retailstore.repository.CustomerRepository;

@Service
public class CustomerService {
	
	@Autowired
	private CustomerRepository customerRepository;
	
	private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    /**
     * Add a new customer with hashed password.
     */
    public Customer addCustomer(Customer customer) {
        customer.setPassword(passwordEncoder.encode(customer.getPassword())); // Hash password
        return customerRepository.save(customer);
    }
	
	
	
	public Customer searchCustomer(int customerId) {
		
		Optional<Customer> byId= customerRepository.findById(customerId);
		Customer dummy = new Customer();
		return byId.orElse(dummy);
		
	}
	
	public String deleteCustomer(int customerId) {
		customerRepository.deleteById(customerId);
		return "Deleted Succesfully";
	}
	
	public Customer updateCustomer(int customerId, Customer customer) {
		Optional<Customer> byId = customerRepository.findById(customerId);
		Customer dummy = new Customer();
		if(byId.isPresent()) {
			Customer customer1 = byId.get();
			customer1.setCustomerName(customer.getCustomerName());
			customer1.setCustomerEmail(customer.getCustomerEmail());
			customer1.setCustomerBillingAddress(customer.getCustomerBillingAddress());
			customer1.setCustomerShippingAddress(customer.getCustomerShippingAddress());
			return customerRepository.save(customer1);

			
		}
		return dummy;
	}
	
	 public Customer authenticateCustomer(String email, String rawPassword) {
	        Optional<Customer> customerOpt = customerRepository.findByCustomerEmail(email);

	        if (customerOpt.isPresent()) {
	            Customer customer = customerOpt.get();
	            if (passwordEncoder.matches(rawPassword, customer.getPassword())) {
	                return customer; // Return the authenticated customer
	            }
	        }

	        return createDummyCustomer(); // Return dummy for invalid login
	    }

	    /**
	     * Creates a dummy customer object.
	     */
	    private Customer createDummyCustomer() {
	        return Customer.builder()
	                .id(0)
	                .customerName("Unknown")
	                .customerEmail("unknown@example.com")
	                .password("")
	                .customerBillingAddress(null)
	                .customerShippingAddress(null)
	                .build();
	    }
	}


