package com.retailstore.cart.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.retailstore.cart.entity.Cart;
import com.retailstore.cart.entity.LineItem;
import com.retailstore.cart.repository.CartRepository;

@Service
public class CartService {
	
	@Autowired
    private CartRepository cartRepository;
	
	public Cart addCart(Cart cart) {


	return cartRepository.save(cart);
	}
	
	public Optional<Cart> getCart(Long cartId) {
		return cartRepository.findById(cartId);
	}
	
	public Cart updateCart(Long cartId, Cart updatedCart) { 
		return cartRepository.findById(cartId).map(cart -> {

			cart.getLineItems().clear();

			if (updatedCart.getLineItems() != null) {
				for (LineItem item: updatedCart.getLineItems()) 
				{ cart.getLineItems().add(item);
			}
			}

			else { System.out.println("It entered Else");
			
			}

			return cartRepository.save(cart);
			
			})

			.orElseThrow(() -> new RuntimeException("Cart not found"));

			}
	
	public void emptyCart(long cartId) {

	
	Optional<Cart> existingCartOpt = cartRepository.findById(cartId);

	if (existingCartOpt.isPresent()) {

	Cart existingCart = existingCartOpt.get();

	existingCart.getLineItems().clear(); // Clear the list instead of replacing it cartRepository.save(existingCart); // Hibernate will handle orphan removal

	} else {

	throw new RuntimeException("Cart not found with id " + cartId);

	}
	}
	
	
public void deleteCart(Long cartId) {

		
			cartRepository.deleteById(cartId);

			
	

}
	}
