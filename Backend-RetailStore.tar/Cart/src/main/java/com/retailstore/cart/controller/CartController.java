package com.retailstore.cart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.retailstore.cart.entity.Cart;
import com.retailstore.cart.service.CartService;

@RestController
@RequestMapping("/api/cart")
public class CartController {
	
	@Autowired
	private final  CartService cartService;

	
	public CartController(CartService cartService) { 
		
		this.cartService = cartService;
	}

	@PostMapping
    public ResponseEntity<Cart> addCart (@RequestBody Cart cart) {

	Cart savedCart = cartService.addCart(cart);

	return new ResponseEntity<>(savedCart, HttpStatus.CREATED);
}

	@GetMapping("/{id}")
	public ResponseEntity<Object> getCart(@PathVariable Long id) {

	return cartService.getCart(id) .map(cart -> ResponseEntity.ok((Object) cart))

	.orElseGet(()-> ResponseEntity.status(HttpStatus.NOT_FOUND).body("Cart not found"));
	
	}

	@PutMapping("/{id}")

	public ResponseEntity<Cart> updateCart(@PathVariable Long id, @RequestBody Cart updatedCart) {
	Cart cart = cartService.updateCart(id, updatedCart);

	return new ResponseEntity<>(cart, HttpStatus.OK);
	}

	@DeleteMapping("delete/{id}")
	public ResponseEntity<String> deleteCart(@PathVariable Long id) {
		cartService.deleteCart(id);

	return new ResponseEntity<>("Deleted Successfully", HttpStatus.OK);
	
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<String> emptyCart (@PathVariable long id) {
	cartService.emptyCart(id); return new ResponseEntity<String>("Line Items deleted",HttpStatus.OK);

}
}
