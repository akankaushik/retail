package com.retailstore.shipping.feign;

import java.util.Optional;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.retailstore.shipping.entity.Order;

//@FeignClient(url = "http://localhost:8095", name = "order-service")
@FeignClient(value = "Order")
public interface OrderFeignClient {

    @PostMapping("/api/order")
    public Order addOrder(@RequestBody Order order);

    @GetMapping("/api/order/{id}")
    public Optional<Order> getOrder(@PathVariable Long id);

    @PutMapping("/api/order/{id}")
    public Order updateOrder(@PathVariable Long id, @RequestBody Order updatedOrder);

    @DeleteMapping("/api/order/{id}")
    public String deleteOrder(@PathVariable Long id);
}

