package com.retailstore.shipping.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.retailstore.shipping.dto.ProductQuantityDto;
import com.retailstore.shipping.entity.Cart;
import com.retailstore.shipping.entity.Customer;
import com.retailstore.shipping.entity.CustomerCart;
import com.retailstore.shipping.entity.CustomerOrder;
import com.retailstore.shipping.entity.Inventory;
import com.retailstore.shipping.entity.LineItem;
import com.retailstore.shipping.entity.Order;
import com.retailstore.shipping.entity.Product;
import com.retailstore.shipping.feign.CartFeignClient;
import com.retailstore.shipping.feign.CustomerFeignClient;
import com.retailstore.shipping.feign.InventoryFeignClient;
import com.retailstore.shipping.feign.OrderFeignClient;
import com.retailstore.shipping.feign.ProductFeignClient;
import com.retailstore.shipping.repository.CustomerCartRepository;
import com.retailstore.shipping.repository.CustomerOrderRepository;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

public class ShoppingService {
	
	@Autowired
	private CustomerCartRepository customerCartRepository;
	
	@Autowired
	private CustomerOrderRepository customerOrderRepository;
	
	@Autowired
	private ProductFeignClient productFeignClient;
	
	private InventoryFeignClient inventoryFeignClient;
	
	private CustomerFeignClient customerFeignClient;
	
	private CartFeignClient cartFeignClient;
	
	private OrderFeignClient orderFeignClient;





	
	
	
	
	
	public Cart getCart(long customerId) {
	    Optional<CustomerCart> custCartOpt = customerCartRepository.findByCustomerId(customerId);
	    long cartId = custCartOpt.get().getCartId();
	    Optional<Cart> cart = cartFeignClient.getCart(cartId);
	    return cart.get();
	}

	public Customer getCustomer(long customerId) {
	    return this.customerFeignClient.searchCustomer(customerId);
	}

	public List<Product> getAllProducts() {
	    return productFeignClient.getAllProducts();
	}

	@CircuitBreaker(fallbackMethod = "createProductFallback", name = "fallBackForCreateProduct")
	public String createProduct(ProductQuantityDto productQuantityDto) {
	    System.out.println("Create product called:");
	    Product product = Product.builder()
	            .productName(productQuantityDto.getProductName())
	            .productDescription(productQuantityDto.getProductDescription())
	            .productPrice(productQuantityDto.getProductPrice())
	            .build();
	    Product savedProduct = productFeignClient.addProduct(product);

	    Inventory inventory = Inventory.builder()
	            .productId(savedProduct.getId())
	            .quantity(productQuantityDto.getQuantity())
	            .build();
	    Inventory savedInventory = inventoryFeignClient.addInventory(inventory);

	    return "Product and Inventory Updated Successfully";
	}

	public String createProductFallback(ProductQuantityDto productQuantityDto, Throwable exception) {
	    System.out.println("Create product fallback called due to: " + exception.getMessage());
	    return "Product or Inventory Service is currently down. Please try again later.";
	}
	
	@CircuitBreaker(fallbackMethod = "addCustomerFallback", name = "fallBackForAddCustomer")
	public CustomerCart addCustomer(Customer customer) {
	    Customer savedCustomer = customerFeignClient.addCustomer(customer);

	    Cart cart = new Cart();
	    List<LineItem> lineItems = new ArrayList<>();
	    cart.setLineItems(lineItems);

	    Cart savedCart = cartFeignClient.addCart(cart);

	    CustomerCart customerCart = CustomerCart.builder()
	            .customerId(savedCustomer.getId())
	            .cartId(savedCart.getCartId())
	            .build();

	    return customerCartRepository.save(customerCart);
	}

	public CustomerCart addCustomerFallback(Customer customer, RuntimeException exception) {
	    System.out.println("Add customer fallback called due to " + exception.getMessage());
	    CustomerCart defaultCustomerCart = new CustomerCart();
	    defaultCustomerCart.setId(0);
	    defaultCustomerCart.setCustomerId(0);
	    defaultCustomerCart.setCartId(0);
	    return defaultCustomerCart;
	}

	@CircuitBreaker(fallbackMethod = "addItemsToCartFallback", name = "fallBackForAddItemsToCart")
	public Cart addItemsToCart(Cart cart, long customerId) {
	    Optional<CustomerCart> custCartOpt = customerCartRepository.findByCustomerId(customerId);
	    long cartId = custCartOpt.get().getCartId();
	    cart.setCartId(cartId);
	    return cartFeignClient.updateCart(cartId, cart);
	}

	public Cart addItemsToCartFallback(Cart cart, long customerId, RuntimeException exception) {
	    System.out.println("Add items to cart fallback called due to " + exception.getMessage());
	    Cart defaultCart = new Cart();
	    return defaultCart;
	}
	
	@CircuitBreaker(fallbackMethod = "createOrderFallback", name = "fallBackForCreateOrder")
	public Order createOrder(long customerId) {
	    Optional<CustomerCart> customerCartOpt = customerCartRepository.findByCustomerId(customerId);
	    long cartId = customerCartOpt.get().getCartId();
	    Optional<Cart> cart = cartFeignClient.getCart(cartId);

	    if (cart.get().getLineItems().isEmpty()) {
	        throw new RuntimeException("Cart is empty");
	    }

	    // Reduce inventory for each line item in the cart
	    for (LineItem lineItem : cart.get().getLineItems()) {
	        // Fetch current inventory for the product
	        Inventory inventory = inventoryFeignClient.searchInventory(lineItem.getProductId());
	        System.out.println(inventory);

	        // Reduce the quantity
	        int newQuantity = inventory.getQuantity() - lineItem.getQuantity();
	        if (newQuantity < 0) {
	            throw new RuntimeException("Insufficient inventory for product ID: " + lineItem.getProductId());
	        }

	        // Update the inventory with the new quantity
	        inventory.setQuantity(newQuantity);
	        inventoryFeignClient.updateInventory(inventory.getInventoryId(), inventory);
	    }

	    // Create the order from the cart items
	    Order order = Order.builder()
	            .lineItems(new ArrayList<>(cart.get().getLineItems()))
	            .build();
	    Order savedOrder = orderFeignClient.addOrder(order);

	    // Save the customer order
	    CustomerOrder customerOrder = CustomerOrder.builder()
	            .customerId(customerId)
	            .orderId(savedOrder.getOrderId())
	            .build();
	    customerOrderRepository.save(customerOrder);

	    // Empty the cart after order placement
	    cartFeignClient.emptyCart(cartId);

	    return savedOrder;
	}
	
	public Order createOrderFallback(long customerId, RuntimeException exception) {
	    System.out.println("Create order fallback called due to " + exception.getMessage());
	    Order order = Order.builder().orderId(0).build();
	    
	    LineItem defaultLineItem = LineItem.builder()
	        .productId(0)
	        .productName("Product 0")
	        .quantity(0)
	        .price(0)
	        .build();
	    
	    List<LineItem> defaultLineItemList = new ArrayList<>();
	    defaultLineItemList.add(defaultLineItem);
	    
	    order.setLineItems(defaultLineItemList);
	    
	    return order;
	}

	
	
	
	@CircuitBreaker(fallbackMethod = "getAllOrdersFallback", name = "fallBackForGetAllOrders")
	public List<Order> getAllOrders(long customerId) {
	    List<CustomerOrder> customerOrders = customerOrderRepository.findAllByCustomerId(customerId);

	    List<Order> orders = new ArrayList<>();

	    customerOrders.forEach(customerOrder -> {
	        orders.add(orderFeignClient.getOrder(customerOrder.getOrderId()).get());
	    });
	    return orders;
	}

	public List<Order> getAllOrdersFallback(long customerId, RuntimeException exception) {
	    System.out.println("Get all orders fallback called due to " + exception.getMessage());
	    Order order = Order.builder().orderId(0).build();
	    LineItem defaultLineItem = LineItem.builder().productId(0).productName("Product 0").quantity(0).price(0).build();

	    List<LineItem> defaultLineItemList = new ArrayList<>();
	    defaultLineItemList.add(defaultLineItem);

	    order.setLineItems(defaultLineItemList);

	    List<Order> defaultOrderList = new ArrayList<>();
	    defaultOrderList.add(order);

	    return defaultOrderList;
	}





}
