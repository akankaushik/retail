package com.retailstore.controller;
import org.springframework.web.bind.annotation.RequestParam;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.retailstore.entity.Customer;
import com.retailstore.service.CustomerService;

@RestController
@RequestMapping("/api/customer")
public class CustomerController {
	
	@Autowired
    private CustomerService customerService;
	
	/**
     * Authenticate a customer.
     */
    @PostMapping("/login")
    public ResponseEntity<Customer> loginCustomer(@RequestParam String email, @RequestParam String password) {
        Customer authenticatedCustomer = customerService.authenticateCustomer(email, password);
        return ResponseEntity.ok(authenticatedCustomer);
    }
	
	
	@GetMapping("/searchCustomer/{customerId}")
	public ResponseEntity<Customer> searchCustomer(@PathVariable int customerId){
		return ResponseEntity.status(HttpStatus.OK).body(customerService.searchCustomer(customerId));
	}

    /**
     * Add a new customer with billing and shipping addresses.
     */
    @PostMapping("/addCustomer")
    public ResponseEntity<Customer> addCustomer(@RequestBody Customer customer) {
        Customer savedCustomer = customerService.addCustomer(customer);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedCustomer);
    }

    /**
     * Delete a customer by ID.
     */
    @DeleteMapping("/deleteCustomer/{customerId}")
    public ResponseEntity<Void> deleteCustomer(@PathVariable int customerId) {
        customerService.deleteCustomer(customerId);
        return ResponseEntity.noContent().build();
    }

    /**
     * Update customer details by ID.
     */
    @PutMapping("/updateCustomer/{customerId}")
    public ResponseEntity<Customer> updateCustomer(
            @PathVariable int customerId,
            @RequestBody Customer customer) {
        Customer updatedCustomer = customerService.updateCustomer(customerId, customer);
        return ResponseEntity.ok(updatedCustomer);
    }


}
