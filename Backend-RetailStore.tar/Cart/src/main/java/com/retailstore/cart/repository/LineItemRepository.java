package com.retailstore.cart.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.retailstore.cart.entity.LineItem;

@Repository
public interface LineItemRepository extends JpaRepository<LineItem, Long> {
}
