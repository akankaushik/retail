package com.retailstore.order.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.retailstore.order.entity.LineItem;
import com.retailstore.order.entity.Order;
import com.retailstore.order.repository.OrderRepository;

@Service
public class OrderService {
	
	@Autowired
    private OrderRepository orderRepository;
	
	public Order addOrder(Order order) {
		return orderRepository.save(order);
		
	}
	
	public Optional<Order> getOrder(Long orderId){
		return orderRepository.findById(orderId);
		
	}
	
	public Order updateCart(Long orderId, Order updatedOrder) { 
		return orderRepository.findById(orderId).map(order -> {

			order.getLineItems().clear();

			
				for (LineItem item: updatedOrder.getLineItems()) { 
					order.getLineItems().add(item);
			}

			return orderRepository.save(order);
			
			})

			.orElseThrow(() -> new RuntimeException("Cart not found"));

			}
	public void deleteOrder(Long orderId) {
		orderRepository.deleteById(orderId);
	}
  


}
