package com.retailstore.shipping.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.retailstore.shipping.entity.CustomerCart;

public interface CustomerCartRepository extends JpaRepository<CustomerCart,Long> {
	
	public Optional<CustomerCart> findByCustomerId(long customerId);

}
