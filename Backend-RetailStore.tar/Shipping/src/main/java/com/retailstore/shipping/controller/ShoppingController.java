package com.retailstore.shipping.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.retailstore.shipping.dto.ProductQuantityDto;
import com.retailstore.shipping.entity.Cart;
import com.retailstore.shipping.entity.Customer;
import com.retailstore.shipping.entity.CustomerCart;
import com.retailstore.shipping.entity.Order;
import com.retailstore.shipping.entity.Product;
import com.retailstore.shipping.service.ShoppingService;

@RestController
@RequestMapping("/api/shoppingService")
public class ShoppingController {

    @Autowired
    private ShoppingService shoppingService;

    @GetMapping("/customer/{customerId}/cart")
    public ResponseEntity<Cart> getCart(@PathVariable long customerId) {
        return ResponseEntity.status(HttpStatus.OK).body(this.shoppingService.getCart(customerId));
    }

    @GetMapping("/getCustomer/{customerId}")
    public ResponseEntity<Customer> getCustomer(@PathVariable long customerId) {
        return ResponseEntity.status(HttpStatus.OK).body(this.shoppingService.getCustomer(customerId));
    }

    @PostMapping("/products")
    public ResponseEntity<Map<String, String>> addProduct(@RequestBody ProductQuantityDto product) {
        // Logic to add product
        Map<String, String> response = new HashMap<>();
        response.put("message", shoppingService.createProduct(product));
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @GetMapping("/products/getAllProducts")
    public ResponseEntity<List<Product>> getAllProducts() {
        return ResponseEntity.status(HttpStatus.OK).body(shoppingService.getAllProducts());
    }

    @PostMapping("/customer")
    public ResponseEntity<CustomerCart> addCustomer(@RequestBody Customer customer) {
        return ResponseEntity.status(HttpStatus.CREATED).body(shoppingService.addCustomer(customer));
    }

    @PutMapping("/customer/{customerId}/cart")
    public ResponseEntity<Cart> addItemsToCart(@RequestBody Cart cart, @PathVariable("customerId") long customerId) {
        return ResponseEntity.status(HttpStatus.OK).body(shoppingService.addItemsToCart(cart, customerId));
    }

    @PostMapping("/customer/{customerId}/order")
    public ResponseEntity<Order> createOrder(@PathVariable long customerId) {
        return ResponseEntity.status(HttpStatus.CREATED).body(shoppingService.createOrder(customerId));
    }

    @GetMapping("/customer/{customerId}/orders")
    public ResponseEntity<List<Order>> getAllOrders(@PathVariable long customerId) {
        return ResponseEntity.status(HttpStatus.OK).body(shoppingService.getAllOrders(customerId));
    }

}

