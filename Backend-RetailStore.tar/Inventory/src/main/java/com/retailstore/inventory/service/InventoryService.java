package com.retailstore.inventory.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.retailstore.inventory.entity.Inventory;
import com.retailstore.inventory.repository.InventoryRepository;

@Service
public class InventoryService {
	
	@Autowired
	private InventoryRepository inventoryRepository;
	
	public List<Inventory> getAllInventories() { 
		return inventoryRepository.findAll();
		
	}
	
	public Inventory addInventory (Inventory inventory) { 
		
		return inventoryRepository.save(inventory); 
		}
	
	public String deleteInventory(long inventoryId) {
		inventoryRepository.deleteById(inventoryId);
		return "Deleted Sucessfully";
	
	};
	
	public Inventory updateInventory(long inventoryId, Inventory inventory) { 
		
		Optional<Inventory> byId = inventoryRepository.findById(inventoryId);

	     if(byId.isPresent()){ 
	    	 Inventory existingInventory= byId.get();

	 existingInventory.setProductId(inventory.getProductId());

	existingInventory.setQuantity(inventory.getQuantity()); 
	return inventoryRepository.save(existingInventory);
	     }
	return null; // 


	}
	
	public Inventory searchInventory(long inventoryId) {


			Optional<Inventory> byId = inventoryRepository.findById(inventoryId); 
			return byId.orElse(null);

	}

}
