package com.retailstore.shipping.entity;




import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CustomerAddress {
	

	private long id;
	private String doorNo;
	private String streetName;
	private String layout;
	private String city;
	private String pincode;
	
	

}
