package com.retailstore.shipping.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.retailstore.shipping.entity.Customer;

//@FeignClient(url = "http://localhost:8094/api/customer", value = "customer-service")
@FeignClient(value = "Customer/api/customer")
public interface CustomerFeignClient {

    @GetMapping("/searchCustomer/{customerId}")
    public Customer searchCustomer(@PathVariable long customerId);

    @PostMapping("/addCustomer")
    public Customer addCustomer(@RequestBody Customer customer);

    @DeleteMapping("/deleteCustomer/{customerId}")
    public String deleteCustomer(@PathVariable int customerId);

    @PutMapping("/updateCustomer/{customerId}")
    public Customer updateCustomer(@PathVariable int customerId, @RequestBody Customer customer);
}

