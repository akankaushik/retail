package com.retailstore.order.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.retailstore.order.entity.LineItem;

@Repository
public interface LineItemRepository extends JpaRepository<LineItem, Long> {
}


